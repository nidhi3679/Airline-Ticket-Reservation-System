<?php include_once 'helpers/helper.php'; ?>
<?php subview('header.php');    ?>
<link rel="stylesheet" href="assets/css/form.css">
<style>
        /* CSS styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .error {
            color: red;
        }
    </style>
    <div class="container">
<h1><center>TRAVEL GUIDELINES</center></h1>
<ul>
<li>Arrive Early: Arrive at the airport well in advance of your scheduled departure time to allow for check-in, security screening, and any unforeseen delays.</li>
    
<li>Follow Security Procedures: Be prepared to pass through security checkpoints by removing your shoes, belts, jackets, and any metal objects from your person. Liquids should be in containers of 3.4 ounces (100 milliliters) or less and placed in a clear, quart-sized plastic bag.</li>

<li>Respect Luggage Restrictions: Pay attention to airline luggage restrictions regarding size, weight, and number of bags allowed. Consider packing light to expedite the boarding process and minimize inconvenience.</li>

<li>Boarding Process: Board the aircraft according to your assigned group or seat row. Be mindful of other passengers and avoid crowding the boarding area.</li>

<li>Stow Luggage Properly: Place carry-on luggage in the overhead bins or under the seat in front of you. Ensure that all items are securely stowed to prevent shifting during the flight.</li>

<li>Seat Etiquette: Respect your fellow passengers' personal space by keeping your seat upright during meal times and avoiding excessive reclining. If you need to recline your seat, do so gradually and considerate of those behind you.</li>

<li>Follow Crew Instructions: Listen to the flight attendants' instructions regarding safety procedures, seatbelt usage, and any special announcements. Follow their directions promptly and attentively.</li>

<li>Be Courteous: Practice common courtesy and respect towards fellow passengers and airline staff. Avoid loud conversations, refrain from kicking seats, and be mindful of personal hygiene.</li>

<li>Stay Hydrated: Drink plenty of water during the flight to stay hydrated, especially on long journeys. Limit alcohol and caffeine intake, as they can contribute to dehydration.</li>

<li>Keep Essential Items Handy: Keep essential items such as travel documents, medications, and entertainment devices easily accessible during the flight.</li>

<li>Mindful Eating: If offered snacks or meals, be considerate of others when opening food packaging and disposing of trash. Avoid strong-smelling foods out of respect for fellow passengers.</li>

<li>Stay Calm During Turbulence: Remain calm and follow the crew's instructions during turbulence. Keep your seatbelt fastened whenever you are seated, even if the seatbelt sign is turned off.</li>

<li>Respect Electronic Devices Policy: Adhere to the airline's policies regarding the use of electronic devices during the flight. Switch devices to airplane mode when instructed to do so.</li>

<li>Mask Etiquette (if applicable): Follow any mask-wearing guidelines provided by the airline or regulatory authorities to ensure the safety of yourself and others.</li>

<li>Be Patient and Flexible: Flight delays and unexpected events can occur. Maintain patience and flexibility when facing disruptions to your travel plans.</li>
    </ul>
    </div>
 




          
       
  

<footer>
	<em><h5 class=" text-center p-0 brand mt-2">
				<img src="assets/images/plane-logo.png" 
					height="40px" width="40px" alt="">				
			</h5></em>
	<p class=" text-center">&copy; <?php echo date('Y');?> -Airline Ticket Reservation System</p>
</footer>